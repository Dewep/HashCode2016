#!/bin/sh
./hashcode2016 busy_day < data/busy_day.in
./hashcode2016 mother_of_all_warehouses < data/mother_of_all_warehouses.in
./hashcode2016 redundancy < data/redundancy.in
