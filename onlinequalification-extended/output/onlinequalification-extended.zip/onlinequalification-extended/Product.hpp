#ifndef PRODUCT_HPP_
# define PRODUCT_HPP_

struct Product {
    int id;
    int weight;
};

#endif /* !PRODUCT_HPP_ */
